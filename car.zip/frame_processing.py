import globals



def process_frame(frame):
    # Resize the frame for faster processing
    width, height = 320, 240
    frame_resized = globals.cv2.resize(frame, (width, height))

    # Convert to grayscale
    gray_image = globals.cv2.cvtColor(frame_resized, globals.cv2.COLOR_BGR2GRAY)

    # Apply Gaussian blur to reduce noise
    blurred = globals.cv2.GaussianBlur(gray_image, (5, 5), 0)

    # Sobel edge detection
    sobelx = globals.cv2.Sobel(blurred, globals.cv2.CV_16S, 1, 0, ksize=3)
    sobely = globals.cv2.Sobel(blurred, globals.cv2.CV_16S, 0, 1, ksize=3)

    # Combine Sobel gradients
    abs_sobelx = globals.cv2.convertScaleAbs(sobelx)
    abs_sobely = globals.cv2.convertScaleAbs(sobely)
    gradient_magnitude = globals.cv2.addWeighted(abs_sobelx, 0.5, abs_sobely, 0.5, 0)

    # Threshold to get binary image
    _, binary_image = globals.cv2.threshold(gradient_magnitude, 0, 255, globals.cv2.THRESH_BINARY + globals.cv2.THRESH_OTSU)

    # Add morphological opening to reduce noise (remove small blobs)
#    kernel = globals.cv2.getStructuringElement(globals.cv2.MORPH_RECT, (3, 3))
#    binary_image = globals.cv2.morphologyEx(binary_image, globals.cv2.MORPH_OPEN, kernel)

    # Define the region of interest (ROI) to focus on the lower part of the image
    x_roi, y_roi, width_roi, height_roi = 1, 70, 318, 30
    roi = binary_image[y_roi:y_roi + height_roi, x_roi:x_roi + width_roi]

    # Hough Line Transformation to detect track lines
    lines = globals.cv2.HoughLinesP(roi, 1, globals.np.pi / 180, 25, minLineLength=20, maxLineGap=15)

    # Create an output image to draw lines
    output_image = globals.np.zeros_like(binary_image)

    if lines is not None:
        for line in lines:
            x1, y1, x2, y2 = line[0]
            angle = globals.np.degrees(globals.np.arctan2(y2 - y1, x2 - x1))
            if abs(angle) > 15:  # Filter out lines with small angles
                # Adjust line positions based on the ROI
                x1 += x_roi
                y1 += y_roi
                x2 += x_roi
                y2 += y_roi
                globals.cv2.line(output_image, (x1, y1), (x2, y2), (255, 255, 255), 2, globals.cv2.LINE_AA)

    return output_image




def tracking(dilated_image):
    globals.begin = 160
    globals.left_line = []
    globals.right_line = []
    globals.mid = []

    for i in range(100, 69, -1):
        # 使用 NumPy 寻找边界
        left_col = globals.np.where(dilated_image[i, :globals.begin] == 255)[0]
        right_col = globals.np.where(dilated_image[i, globals.begin:] == 255)[0] + globals.begin

        # 查找左边界
        if left_col.size > 0:
            globals.left_line.append((left_col[-1], i))
        else:
            globals.left_line.append((0, i))

        # 查找右边界
        if right_col.size > 0:
            globals.right_line.append((right_col[0], i))
        else:
            globals.right_line.append((dilated_image.shape[1] - 1, i))

        # 计算中点
        if globals.left_line and globals.right_line:
            midx1 = globals.left_line[-1]
            midx2 = globals.right_line[-1]
            mid_point = (int((midx1[0] + midx2[0]) / 2), i)
            globals.mid.append(mid_point)

        # 更新开始位置
        globals.begin = (globals.left_line[-1][0] + globals.right_line[-1][0]) // 2


def left_turn_tracking(dilated_image):
    """
    在左转弯过程中，将当前左白线当作变道后的右白线进行循迹。
    """
    globals.begin = 5  # 设置为最左边，因为左白线就是原赛道的左边界
    globals.left_line = []
    globals.right_line = []
    globals.mid = []

    for i in range(100, 69, -1):
        # 使用 NumPy 寻找边界
        left_col = globals.np.where(dilated_image[i, :globals.begin] == 255)[0]
        right_col = globals.np.where(dilated_image[i, globals.begin:] == 255)[0] + globals.begin

        ## 查找左边界
        if left_col.size > 0:
            globals.left_line.append((left_col[-1], i))
        else:
            globals.left_line.append((0, i))

        # 查找右边界
        if right_col.size > 0:
            globals.right_line.append((right_col[0], i))
        else:
            globals.right_line.append((dilated_image.shape[1] - 1, i))

        # 计算中点
        if globals.left_line and globals.right_line:
            midx1 = globals.left_line[-1]
            midx2 = globals.right_line[-1]
            mid_point = (int((midx1[0] + midx2[0]) / 2), i)
            globals.mid.append(mid_point)

        # 更新开始位置
        globals.begin = (globals.left_line[-1][0] + globals.right_line[-1][0]) // 2

    # 判断是否完成变道的条件
    if len(globals.left_line) > 0 and len(globals.right_line) > 0:
        # 假设当最后一条左白线的 x 坐标大于一个阈值时，认为变道完成
        if globals.left_line[-1][0] > 0 and globals.right_line[-1][0] < dilated_image.shape[1]:
            # 如果检测到新的左白线且车道稳定，认为变道完成
            globals.change_lane_done = True
            print("Lane change completed successfully.")
        else:
            globals.change_lane_done = False  # 变道未完成
            print("Lane change in progress.")


def right_turn_tracking(dilated_image):
    """
    在右转弯过程中，将当前右白线当作变道后的左白线进行循迹。
    """
    globals.begin = dilated_image.shape[1]-1  # 设置为图像的最右边，因为右白线就是原赛道的右边界
    globals.left_line = []
    globals.right_line = []
    globals.mid = []

    for i in range(100, 69, -1):
        # 使用 NumPy 寻找边界
        left_col = globals.np.where(dilated_image[i, :globals.begin] == 255)[0]
        right_col = globals.np.where(dilated_image[i, globals.begin:] == 255)[0] + globals.begin

        ## 查找左边界
        if left_col.size > 0:
            globals.left_line.append((left_col[-1], i))
        else:
            globals.left_line.append((0, i))

        # 查找右边界
        if right_col.size > 0:
            globals.right_line.append((right_col[0], i))
        else:
            globals.right_line.append((dilated_image.shape[1] - 1, i))

        # 计算中点
        if globals.left_line and globals.right_line:
            midx1 = globals.left_line[-1]
            midx2 = globals.right_line[-1]
            mid_point = (int((midx1[0] + midx2[0]) / 2), i)
            globals.mid.append(mid_point)

        # 更新开始位置
        globals.begin = (globals.left_line[-1][0] + globals.right_line[-1][0]) // 2

    # 判断是否完成变道的条件
    if len(globals.left_line) > 0 and len(globals.right_line) > 0:
        # 假设当最后一条右白线的 x 坐标小于图像宽度时，认为变道完成
        if globals.right_line[-1][0] < dilated_image.shape[1]-1 and globals.left_line[-1][0] > 0:
            # 如果检测到新的右白线且车道稳定，认为变道完成
            globals.change_lane_done = True
            print("Lane change completed successfully.")
        else:
            globals.change_lane_done = False  # 变道未完成
            print("Lane change in progress.")



def yellow_edge(img, visual_flag):
    yellow_num = 0
    height, width = img.shape[:2]
    half_height = height // 2
    per_height = height // 20

    # 裁剪感兴趣区域
    cropped_image = img[half_height - per_height:half_height + 2 * per_height, 0:width].copy()

    # 转换为HSV颜色空间
    hsv = globals.cv2.cvtColor(cropped_image, globals.cv2.COLOR_BGR2HSV)
#    lower_yellow = np.array([20, 100, 100])
#    upper_yellow = np.array([30, 255, 255])

    # 定义黄色的阈值范围
#    lower_yellow = globals.np.array([15, 25, 150])
#    lower_yellow = globals.np.array([20, 100, 100])
    lower_yellow = globals.np.array([20, 60, 100])
    upper_yellow = globals.np.array([35, 255, 255])

    # 生成掩膜，提取黄色区域
    mask = globals.cv2.inRange(hsv, lower_yellow, upper_yellow)

    # 应用形态学操作以去除噪声
    kernel = globals.np.ones((5, 5), globals.np.uint8)
    mask = globals.cv2.erode(mask, kernel, iterations=1)
    mask = globals.cv2.dilate(mask, kernel, iterations=1)

    # 获取开始时间
    start_time = globals.time.time()

    # 查找轮廓
    contours, _ = globals.cv2.findContours(mask, globals.cv2.RETR_TREE, globals.cv2.CHAIN_APPROX_SIMPLE)

    if contours:
        for contour in contours:
            # 计算轮廓的面积并判断是否符合条件
            area = globals.cv2.contourArea(contour)
            if area > 5:  # 设定面积阈值，避免噪声
                yellow_num += 1
                if visual_flag:
                    globals.cv2.drawContours(cropped_image, [contour], -1, (0, 255, 0), 2)

    # 获取结束时间并计算处理时间
    end_time = globals.time.time()
    processing_time = (end_time - start_time) * 1000  # 转换为毫秒
    print(f"处理一帧的时间: {processing_time:.6f} 毫秒")

    if visual_flag:
        globals.cv2.imshow("Yellow Mask", mask)
        globals.cv2.imshow("Detected Yellow Lines", cropped_image)
        globals.cv2.waitKey(1)  # 使用 1 毫秒的等待时间实现实时显示

    return yellow_num



def crossroad(frame):
    globals.flag_cross = 0
    height, width = frame.shape[:2]

    # Convert the frame to HSV color space
    hsv = globals.cv2.cvtColor(frame, globals.cv2.COLOR_BGR2HSV)

    # Define the range for white color in HSV
    lower_white = globals.np.array([0, 0, 221])
    upper_white = globals.np.array([180, 30, 255])

    # Create a mask to isolate white arease
    mask1 = globals.cv2.inRange(hsv, lower_white, upper_white)
    kernel_size = 5

    # Apply morphological transformations to clean the mask
    kernel = globals.cv2.getStructuringElement(globals.cv2.MORPH_RECT, (kernel_size, kernel_size))
    mask1 = globals.cv2.dilate(mask1, kernel)
    mask1 = globals.cv2.erode(mask1, kernel)
    src = mask1[105:165, 50:270]

    # Define a region of interest (ROI) for zebra crossing detection
#    src = mask1[85:145, 100:220]  # Focusing on the bottom part of the image

    # 使用 NumPy 计算斑马线的条件
    # 查找连续的斑马线模式
    patterns = (
        (src[:, 2:-2] == 0) & (src[:, 1:-3] == 0) & (src[:, :-4] == 0) &
        (src[:, 3:-1] == 255) & (src[:, 4:] == 255)
    ) | (
        (src[:, 2:-2] == 255) & (src[:, 1:-3] == 255) & (src[:, :-4] == 255) &
        (src[:, 3:-1] == 0) & (src[:, 4:] == 0)
    )

    # 计算符合条件的行数
    detected_count = patterns.sum(axis=1)

    # 检测阈值
    flag = (detected_count >= 7).sum()

    if flag >=	3:
        print("Zebra crossing detected!")
        globals.flag_cross = 1

    print(f"flag_cross: {globals.flag_cross}")
    return globals.flag_cross


# 获取蓝色遮挡物的二值掩码
def get_blue_mask(frame):
    hsv_frame = globals.cv2.cvtColor(frame, globals.cv2.COLOR_BGR2HSV)  # 将BGR颜色空间转换为HSV
#    lower_bound = globals.np.array([90, 50, 50], dtype=globals.np.uint8)  # 蓝色的下界
#    upper_bound = globals.np.array([120, 255, 255], dtype=globals.np.uint8)  # 蓝色的上界
    lower_bound = globals.np.array([0, 120, 120], dtype=globals.np.uint8)  # hong色的下界
    upper_bound = globals.np.array([15, 255, 255], dtype=globals.np.uint8)  # hong色的上界
    mask = globals.cv2.inRange(hsv_frame, lower_bound, upper_bound)  # 创建蓝色的二值掩码
    kernel = globals.np.ones((5, 5), globals.np.uint8)  # 定义5x5的内核用于形态学操作
    mask = globals.cv2.dilate(mask, kernel, iterations=1)  # 扩展蓝色区域
    mask = globals.cv2.erode(mask, kernel, iterations=1)  # 腐蚀以消除噪声
    return mask


def blue_card_find(mask, frame):
    # 查找轮廓
    contours, hierarchy = globals.cv2.findContours(mask, globals.cv2.RETR_EXTERNAL, globals.cv2.CHAIN_APPROX_NONE)

    if len(contours) > 0:
        # 按面积对轮廓进行排序
        contours = sorted(contours, key=globals.cv2.contourArea, reverse=True)

        newContours = []
        for contour in contours:
            # 最小包围圆的中心和半径
            center, radius = globals.cv2.minEnclosingCircle(contour)

            # 过滤掉y坐标不在90和160之间的轮廓
            if 90 < center[1] < 160:
                newContours.append(contour)

        # 更新轮廓
        contours = newContours

        if len(contours) > 0:
            # 判断面积大于500的轮廓
            if globals.cv2.contourArea(contours[0]) > 500:
                print("find biggest blue")
                # 画出最大的包围圆
                center, radius = globals.cv2.minEnclosingCircle(contours[0])
                center = (int(center[0]), int(center[1]))
                radius = int(radius)
                globals.cv2.circle(frame, center, radius, (0, 255, 0), 2)
                globals.find_first = 1
            else:
                print("not found blue")
        else:
            print("not found blue")
    else:
        print("not found blue")


def blue_card_remove(mask):

    print("entry move blue process")

    # 查找轮廓
    contours, hierarchy = globals.cv2.findContours(mask, globals.cv2.RETR_EXTERNAL, globals.cv2.CHAIN_APPROX_NONE)

    if len(contours) > 0:
        # 按面积从大到小排序轮廓
        contours = sorted(contours, key=globals.cv2.contourArea, reverse=True)

        # 过滤轮廓：只保留中心点y坐标在90到160之间的轮廓
        newContours = []
        for contour in contours:
            center, radius = globals.cv2.minEnclosingCircle(contour)
            if 90 < center[1] < 160:
                newContours.append(contour)

        contours = newContours

        if len(contours) == 0:
            globals.begin_sign = 0
            print("move")
            globals.time.sleep(2)
    else:
        globals.begin_sign = 0
        print("蓝色挡板移开")
        globals.time.sleep(2)


def detect_cone(frame):
    """从原始图像中检测蓝色锥桶的位置"""
    # 定义ROI区域，第70到100行
    roi = frame[120:240, :]

    # 转换为HSV色彩空间
    hsv = globals.cv2.cvtColor(roi, globals.cv2.COLOR_BGR2HSV)
    lower_blue = globals.np.array([0, 120, 120])#红
    upper_blue = globals.np.array([15, 255, 255])
#    lower_blue = globals.np.array([90, 50, 50])  # 浅蓝
#    upper_blue = globals.np.array([120, 255, 255])
    mask = globals.cv2.inRange(hsv, lower_blue, upper_blue)

    # 仅寻找大轮廓，避免小噪声干扰
    contours, _ = globals.cv2.findContours(mask, globals.cv2.RETR_TREE, globals.cv2.CHAIN_APPROX_SIMPLE)
    if contours:
        largest_contour = max(contours, key=globals.cv2.contourArea)
        x, y, w, h = globals.cv2.boundingRect(largest_contour)
        # 返回锥桶的坐标（在整个原始图像中的位置）
        return x, y + 120, w, h  # 注意这里返回的 y 值加上了 70 行的偏移
    return None
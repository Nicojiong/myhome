import pigpio as pio
import time
import os

def angleToDutyCycle(angle):
    # 将角度转换为PWM占空比
    return 250 + (angle / 180.0) * (1250 - 250)

# 启动pigpio守护进程
os.system("sudo pigpiod")
time.sleep(2)  # 等待守护进程启动

# 舵机GPIO初始化
servo_pin = 12  # 舵机信号线接树莓派GPIO12
pi1 = pio.pi()

# 检查是否成功连接到pigpio守护进程
if not pi1.connected:
    print("无法连接到pigpio守护进程，请确保pigpio守护进程已启动。")
    exit()

try:
    pi1.set_PWM_frequency(servo_pin, 50)  # frequency 50Hz
    pi1.set_PWM_range(servo_pin, 10000)  # set range 10000
    print("舵机初始化完成！")

    while True:
        # 获取用户输入角度
        angle_input = input("请输入要测试的角度（0-180度），或输入'q'退出: ")
        if angle_input.lower() == 'q':
            break

        try:
            angle = float(angle_input)
            if angle < 0 or angle > 180:
                print("请确保角度在0到180之间！")
                continue

            # 设置舵机到指定角度并打印PWM值
            duty_cycle = angleToDutyCycle(angle)
            pi1.set_PWM_dutycycle(servo_pin, duty_cycle)
            print(f"角度: {angle}, 对应PWM: {duty_cycle}")
            time.sleep(2)  # 等待2秒以稳定舵机

        except ValueError:
            print("输入无效，请输入数字或'q'退出。")

    print("测试完成！")

except KeyboardInterrupt:
    print("\n用户中断，程序即将退出...")

finally:
    # 关闭pigpio守护进程并释放资源
    pi1.stop()
    os.system("sudo killall pigpiod")
    print("pigpio守护进程已关闭。")

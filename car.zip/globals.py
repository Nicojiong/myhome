import cv2
import numpy as np
import pigpio
import time
from datetime import datetime
import yuyin
import m_scontrol
import frame_processing
import exa


# 全局变量初始化
pi = None  # 初始为 None
bin_image2 = None  # 存储处理后的二值化图像
frame = None  # 从摄像头捕获的原始帧
img = None  # 用于图像处理的中间存储
bin_image = None  # 用于存储二值化处理后的图像
change_frame = None  # 存储颜色空间转换后的图像
mask = None  # 存储图像的掩膜
recognized_id=None
binary_image = None  # 存储二值化图像（另一版本）
gray_image = None  # 存储灰度图像
binary_dilated=None
# 轮廓和线条检测相关变量
contours = []  # 存储单个轮廓的点集
contours_all = []  # 存储多个轮廓的集合


cone_position = None  # 初始值为 None
cone_detected_count = 0  # 用于记录连续检测到锥桶的次数
detection_threshold = 8 # 连续检测到锥桶的阈值次数
cone_position_history = []  # 存储最近几帧的锥桶检测结果
turn_direction = 'right'
turn_crossroad=None

yuyintag=0
# 控制相关变量
number1 = 0  # 计数器变量，用于统计或控制逻辑
number2=0
heighest = 100  # 记录检测到的最高位置或值
count_change = 0  # 记录切换次数
begin_sign = 1  # 控制是否开始处理的标志位
find_first = 0  # 标记是否找到第一个特定目标

change_lane_done = False  # 初始状态为未完成

yellow_num_hsv=0;
flag_yellow_finish = 0  # 标记黄色线处理是否完成
flag_cross_finish = 0  # 标记交叉点处理是否完成
cross = None  # 存储交叉点检测的结果
now_blue_max = 0  # 当前检测到的最大蓝色区域面积
flag_cross = 0  # 标记是否检测到交叉点
patching_line1 = [1, 0]  # 补线的方式1
patching_line2 = [0, 1]  # 补线的方式2
try_patching_line = 1  # 当前使用的补线方式
last_blue = 0  # 记录最后一次检测到的蓝色区域
times4 = 0  # 记录某个操作的次数
visual_flag=False
# 图像处理中的点和线相关变量
kp = 1.0# PID控制算法中的比例系数
kd =2.0  # PID控制算法中的微分系数
servo_pwm_now = 0  # 当前伺服电机的PWM值

error_first = 0  # 当前误差
last_error = 0  # 上一次的误差
servo_pwm_diff = 0  # PWM的差值
servo_pwm = 0  # 当前伺服电机的PWM值

# 线检测的坐标点集合
left_line = []  # 存储检测到的左边线条的坐标点
right_line = []  # 存储检测到的右边线条的坐标点
mid = []  # 存储检测到的中间线条的坐标点
left_line_blue = []  # 存储蓝色线条的左边坐标点
right_line_blue = []  # 存储蓝色线条的右边坐标点
mid_blue = []  # 存储蓝色线条的中间坐标点

# GPIO引脚配置常量
SERVO_PIN = 12  # 伺服电机的GPIO引脚编号
SERVO_PWM_RANGE=10000
SERVO_PWM_FREQUENCY = 50  # 伺服电机的PWM频率
SERVO_PWM_DUTY_CYCLE_UNLOCK = 820  # 伺服电机的初始PWM脉宽

MOTOR_PIN = 13  # 电机的GPIO引脚编号
MOTOR_PWM_RANGE = 40000 # 电机的PWM范围
MOTOR_PWM_FREQUENCY = 200 # 电机的PWM频率
MOTOR_PWM_DUTY_CYCLE_UNLOCK = 10000  # 电机的初始PWM占空比

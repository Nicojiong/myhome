import globals
import signal
import sys
import threading
import time
import random
import onnxruntime as ort

crossroad_running = True
yellow_edge_running = True
image_recognition_running = True
stop = False
compile_dir = '/home/pi/test5/RaspberryPiSDK-master/Linux_voice_1.109/samples/tts_sample'
bin_dir = '/home/pi/test5/RaspberryPiSDK-master/Linux_voice_1.109/bin'
audio_file = "/home/pi/test5/yes.wav"
# 加载 ONNX 模型
model_pb_path = './a.onnx'
so = ort.SessionOptions()
net = ort.InferenceSession(model_pb_path, so)

# 标签字典
dic_labels = {0: 'right', 1: 'cross', 2: 'left', 3: 'A', 4: 'B'}

# 模型参数
model_h = 256
model_w = 256
nl = 3
na = 3
stride = [8., 16., 32.]
anchors = [[10, 13, 16, 30, 33, 23], [30, 61, 62, 45, 59, 119], [116, 90, 156, 198, 373, 326]]
anchor_grid = globals.np.asarray(anchors, dtype=globals.np.float32).reshape(nl, -1, 2)
# 用于控制线程是否继续运行的事件
crossroad_event = threading.Event()
# 事件对象，用于通知线程停止
yellow_edge_event = threading.Event()

# 用于控制线程是否继续运行的事件
image_recognition_event = threading.Event()


def plot_one_box(x, img, color=None, label=None, line_thickness=None):
    # 绘制目标框的函数
    tl = (
            line_thickness or round(0.002 * (img.shape[0] + img.shape[1]) / 2) + 1
    )
    color = color or [random.randint(0, 255) for _ in range(3)]
    c1, c2 = (int(x[0]), int(x[1])), (int(x[2]), int(x[3]))
    globals.cv2.rectangle(img, c1, c2, color, thickness=tl, lineType=globals.cv2.LINE_AA)
    if label:
        tf = max(tl - 1, 1)
        t_size = globals.cv2.getTextSize(label, 0, fontScale=tl / 3, thickness=tf)[0]
        c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
        globals.cv2.rectangle(img, c1, c2, color, -1, globals.cv2.LINE_AA)  # 填充
        globals.cv2.putText(
            img,
            label,
            (c1[0], c1[1] - 2),
            0,
            tl / 3,
            [225, 255, 255],
            thickness=tf,
            lineType=globals.cv2.LINE_AA,
        )


def _make_grid(nx, ny):
    xv, yv = globals.np.meshgrid(globals.np.arange(ny), globals.np.arange(nx))
    return globals.np.stack((xv, yv), 2).reshape((-1, 2)).astype(globals.np.float32)


def cal_outputs(outs, nl, na, model_w, model_h, anchor_grid, stride):
    row_ind = 0
    grid = [globals.np.zeros(1)] * nl
    for i in range(nl):
        h, w = int(model_w / stride[i]), int(model_h / stride[i])
        length = int(na * h * w)
        if grid[i].shape[2:4] != (h, w):
            grid[i] = _make_grid(w, h)

        outs[row_ind:row_ind + length, 0:2] = (outs[row_ind:row_ind + length, 0:2] * 2. - 0.5 + globals.np.tile(
            grid[i], (na, 1))) * int(stride[i])
        outs[row_ind:row_ind + length, 2:4] = (outs[row_ind:row_ind + length, 2:4] * 2) ** 2 * globals.np.repeat(
            anchor_grid[i], h * w, axis=0)
        row_ind += length
    return outs


def post_process_opencv(outputs, model_h, model_w, img_h, img_w, thred_nms, thred_cond):
    conf = outputs[:, 4].tolist()

    c_x = outputs[:, 0] * (img_w / model_w)
    c_y = outputs[:, 1] * (img_h / model_h)
    w = outputs[:, 2] * (img_w / model_w)
    h = outputs[:, 3] * (img_h / model_h)

    p_cls = outputs[:, 5:]
    if len(p_cls.shape) == 1:
        p_cls = globals.np.expand_dims(p_cls, 1)
    cls_id = globals.np.argmax(p_cls, axis=1)

    p_x1 = globals.np.expand_dims(c_x - w / 2, -1)
    p_y1 = globals.np.expand_dims(c_y - h / 2, -1)
    p_x2 = globals.np.expand_dims(c_x + w / 2, -1)
    p_y2 = globals.np.expand_dims(c_y + h / 2, -1)
    areas = globals.np.concatenate((p_x1, p_y1, p_x2, p_y2), axis=-1)

    areas = areas.tolist()

    # 非极大值抑制
    ids = globals.cv2.dnn.NMSBoxes(areas, conf, thred_cond, thred_nms)
    if len(ids) > 0:
        return globals.np.array(areas)[ids], globals.np.array(conf)[ids], cls_id[ids]
    else:
        return [], [], []


def infer_img(img0, net, model_h, model_w, nl, na, stride, anchor_grid, thred_nms=0.4, thred_cond=0.5):
    img = globals.cv2.resize(img0, (model_w, model_h), interpolation=globals.cv2.INTER_AREA)
    img = globals.cv2.cvtColor(img, globals.cv2.COLOR_BGR2RGB)
    img = img.astype(globals.np.float32) / 255.0
    blob = globals.np.expand_dims(globals.np.transpose(img, (2, 0, 1)), axis=0)

    outs = net.run(None, {net.get_inputs()[0].name: blob})[0].squeeze(axis=0)
    outs = cal_outputs(outs, nl, na, model_w, model_h, anchor_grid, stride)

    img_h, img_w, _ = img0.shape
    boxes, confs, ids = post_process_opencv(outs, model_h, model_w, img_h, img_w, thred_nms, thred_cond)
    return boxes, confs, ids


def signal_handler(sig, frame):
    print("Exiting gracefully...")
    release_resources()
    sys.exit(0)


def release_resources():
    # 停止电机和舵机
    globals.pi.set_PWM_dutycycle(globals.SERVO_PIN, 820)  # 停止舵机
    globals.pi.set_PWM_dutycycle(globals.MOTOR_PIN, 0)  # 停止电机
    globals.capture.release()  # 释放视频捕捉
    globals.cv2.destroyAllWindows()  # 关闭所有OpenCV窗口


def crossroad_thread_func():
    global crossroad_running
    while crossroad_running:
        if crossroad_event.is_set():
            globals.cross = globals.frame_processing.crossroad(globals.frame)
            if globals.flag_cross_finish == 1:
                crossroad_event.clear()
                print("Crossroad detection finished.")
                crossroad_running = False  # 结束循环
        time.sleep(0.01)


def yellow_edge_thread_func():
    global yellow_edge_running
    while yellow_edge_running:  # 使用各自的控制变量
        if yellow_edge_event.is_set():
            globals.yellow_num_hsv = globals.frame_processing.yellow_edge(globals.frame, globals.visual_flag)
            if globals.yellow_num_hsv != 0:
                yellow_edge_event.clear()
                print("Yellow edge detection finished.")
                yellow_edge_running = False
        time.sleep(0.01)


# def image_recognition_thread_func():
#     global image_recognition_running
#     while image_recognition_running:  # 使用各自的控制变量
#         if image_recognition_event.is_set():
#             pred = globals.exa.run_inference(globals.frame, img_size=320)
#             result_frame, detected_objects = globals.exa.postprocess(pred, globals.frame)
#
#             for obj in detected_objects:
#                 if obj['confidence'] > 0.8:
#                     globals.recognized_id = obj['class_id']
#                     print(f"正确识别到物体：ID={obj['class_id']}, 置信度={obj['confidence']:.2f}, 边框={obj['box']}")
#             if globals.recognized_id is not None:
#                 print(f"Recognized ID: {globals.recognized_id}")
#         time.sleep(0.01)

#
def image_recognition_thread_func():
    global image_recognition_running, net, model_h, model_w, nl, na, stride, anchor_grid, dic_labels
    while image_recognition_running:
        # 检查是否需要关闭线程
        # if globals.change_lane_done:
        #     print("Change lane completed. Stopping image recognition thread...")
        #     image_recognition_running = False  # 确保线程状态标志被更新
        #     image_recognition_event.clear()  # 关闭事件触发
        #     break
        # 检查线程是否被激活
        if image_recognition_event.is_set():
            img = globals.frame.copy()
            if img is not None:  # 只在帧有效时进行处理
                t1 = time.time()
                det_boxes, scores, ids = infer_img(img, net, model_h, model_w, nl, na, stride, anchor_grid,
                                                   thred_nms=0.4, thred_cond=0.5)
                t2 = time.time()

                for box, score, id in zip(det_boxes, scores, ids):
                    label = dic_labels[int(id)]
                    print(f"Detected class: {label}, Confidence: {float(score):.2f}, Box coordinates: {box}")

                    # 仅在置信度大于 0.8 时进行处理
                    if float(score) > 0.8:
                        if int(id) == 0:  # 如果是“右转”标志
                            print("Detected Right Turn sign. Proceeding with the next action...")
                            # 执行右转相关操作，例如转向控制
                            #globals.turn_crossroad = 1
                        elif int(id) == 1:  # 如果是“十字路口”标志
                            print("Detected Crossroad sign. Proceeding with the next action...")
                            # 执行十字路口相关操作
                        elif int(id) == 2:  # 如果是“左转”标志
                            print("Detected Left Turn sign. Proceeding with the next action...")
                            # 执行左转相关操作
                            #globals.turn_crossroad = 0
                        elif int(id) == 3:  # 如果是“左转”标志
                            print("Detected Left Turn sign. Proceeding with the next action...")
                            # 执行左转相关操作
                            globals.recognized_id = 0
                        elif int(id) == 4:  # 如果是“右转”标志
                            print("Detected Right Turn sign. Proceeding with the next action...")
                            # 执行右转相关操作
                            globals.recognized_id = 1
                    else:
                        print(f"Detection with low confidence ({float(score):.2f}), skipping...")

                    # Draw bounding box and label on the image
                    plot_one_box(box.flatten().astype(globals.np.int16), img, color=(255, 0, 0),
                                 label="{}:{:.2f}".format(label, float(score)), line_thickness=None)

                if (t2 - t1) == 0:
                    continue

                str_FPS = "FPS: %.2f" % (1. / (t2 - t1))
                print(str_FPS)
                globals.cv2.putText(img, str_FPS, (50, 50), globals.cv2.FONT_HERSHEY_COMPLEX, 1, (0, 255, 0), 3)

            # 检查globals.frame是否为空
            if img is not None:
                # 只为显示调整图像大小
                display_img = globals.cv2.resize(img, (model_w, model_h), interpolation=globals.cv2.INTER_AREA)
                globals.cv2.imshow("video", display_img)
            else:
                print("Error: Received an empty frame")

        # 按键退出
        if globals.cv2.waitKey(1) & 0xFF == ord('q'):
            break
        # 加入休眠，避免线程空转
        time.sleep(0.01)
        #     # 运行推理
        #     # 调用推理函数
        #     det_boxes, scores, ids = infer_img(globals.frame, net, model_h, model_w, nl, na, stride, anchor_grid)
        #
        #     # 遍历检测到的框
        #     for box, score, id in zip(det_boxes, scores, ids):
        #         label = dic_labels[int(id)]
        #         print(f"Detected class: {label}, Confidence: {float(score):.2f}, Box coordinates: {box}")
        #
        #         # 绘制框和标签
        #         plot_one_box(box.flatten().astype(globals.np.int16), globals.frame, color=(255, 0, 0),
        #                      label="{}:{:.2f}".format(label, float(score)), line_thickness=None)
        #
        #     globals.cv2.imshow("frame", globals.frame)  # 显示推理结果
        #
        #     # 清除事件标志，结束推理
        #     #image_recognition_event.clear()
        #
        # time.sleep(0.01)


# 在程序启动时启动所有常驻线程
crossroad_thread = threading.Thread(target=crossroad_thread_func, daemon=True)
yellow_edge_thread = threading.Thread(target=yellow_edge_thread_func, daemon=True)
image_recognition_thread = threading.Thread(target=image_recognition_thread_func, daemon=True)

crossroad_thread.start()
yellow_edge_thread.start()
image_recognition_thread.start()


def main():
    globals.visual_flag = False
    global crossroad_running, yellow_edge_running, image_recognition_running, stop, compile_dir, bin_dir, audio_file

    # 终止任何之前的GPIO设置并初始化伺服电机
    globals.pigpio.pi().stop()
    globals.m_scontrol.servo_motor_pwm_init()

    globals.capture = globals.cv2.VideoCapture(0)
    if not globals.capture.isOpened():
        print("Can not open video file!")
        return -1

    print(f"FPS: {globals.capture.get(globals.cv2.CAP_PROP_FPS)}")
    print(f"Frame Width: {globals.capture.get(globals.cv2.CAP_PROP_FRAME_WIDTH)}")
    print(f"Frame Height: {globals.capture.get(globals.cv2.CAP_PROP_FRAME_HEIGHT)}")

    globals.capture.set(globals.cv2.CAP_PROP_FOURCC, globals.cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))
    globals.capture.set(globals.cv2.CAP_PROP_FPS, 30)
    globals.capture.set(globals.cv2.CAP_PROP_FRAME_WIDTH, 320)
    globals.capture.set(globals.cv2.CAP_PROP_FRAME_HEIGHT, 240)

    start_time = globals.cv2.getTickCount()

    signal.signal(signal.SIGINT, signal_handler)  # 注册信号处理

    try:
        while True:
            ret, globals.frame = globals.capture.read()
            if not ret:
                break

            if globals.begin_sign == 1:
                frame_a = globals.frame.copy()
                globals.mask = globals.frame_processing.get_blue_mask(frame_a)
                # globals.cv2.imshow("Blue Mask", globals.mask)
                globals.contours, _ = globals.cv2.findContours(globals.mask, globals.cv2.RETR_EXTERNAL,
                                                               globals.cv2.CHAIN_APPROX_SIMPLE)
                print(f"Found {len(globals.contours)} contours")
                globals.mask[0:90, :] = 0
                globals.mask[160:, :] = 0

                if globals.find_first == 0:
                    globals.frame_processing.blue_card_find(globals.mask, frame_a)
                else:
                    globals.frame_processing.blue_card_remove(globals.mask)
            else:
                end_time = globals.cv2.getTickCount()
                frame_a = globals.frame.copy()
                change_frame = globals.cv2.cvtColor(frame_a, globals.cv2.COLOR_BGR2HSV)
                scalarl = globals.np.array([100, 43, 46])
                scalarH = globals.np.array([124, 255, 255])
                globals.mask = globals.cv2.inRange(change_frame, scalarl, scalarH)

                kernel = globals.cv2.getStructuringElement(globals.cv2.MORPH_RECT, (5, 5))
                globals.mask = globals.cv2.morphologyEx(globals.mask, globals.cv2.MORPH_OPEN, kernel)
                globals.mask = globals.cv2.morphologyEx(globals.mask, globals.cv2.MORPH_CLOSE, kernel)

                globals.bin_image = globals.frame_processing.process_frame(globals.frame)
                # 根据条件设置事件，而不是启动线程
                if globals.flag_cross_finish == 0 and globals.number1 > 1680:#1320
                    crossroad_event.set()
                    print("crossroad_event is begin right away!")

                if globals.flag_cross_finish == 1 and globals.count_change > 2:
                    yellow_edge_event.set()
                    print("yellow_edge_event is begin right away")

                # if globals.flag_cross_finish == 1 and globals.count_change>2 :
                #     image_recognition_event.set()  # 设置事件，启动线程
                #     print("image_recognition_event is begin right away")

                if globals.flag_cross_finish == 1 :
                    image_recognition_event.set()  # 设置事件，启动线程
                    print("image_recognition_event is begin right away")

                # if globals.yellow_num_hsv != 0 and not image_recognition_running:
                #     print("Yellow edge detected. Starting image recognition thread...")
                #     image_recognition_running = True  # 确保线程状态标志被更新
                #     image_recognition_event.set()     # 激活事件，使线程进入工作状态

                globals.frame_processing.tracking(globals.bin_image)  # 正常的循迹
                globals.bin_image2 = globals.bin_image.copy()
                #               # 先执行正常的循迹处理
                #               if globals.flag_cross_finish == 1 and not globals.change_lane_done:
                #                   # 判断是否为左转或右转变道状态
                #                   if globals.turn_crossroad == 0:
                #                       # 左转变道
                #                       print("Performing left turn tracking...")
                #                       globals.frame_processing.left_turn_tracking(globals.bin_image)  # 执行左转变道追踪
                #                   elif globals.turn_crossroad == 1:
                #                       # 右转变道
                #                       print("Performing right turn tracking...")
                #                       globals.frame_processing.right_turn_tracking(globals.bin_image)  # 执行右转变道追踪
                #               else:
                #                   # 在其他情况下，执行正常的循迹
                #                   print("Performing regular tracking...")
                #                   globals.frame_processing.tracking(globals.bin_image)  # 正常的循迹

                if globals.begin_sign == 0 and globals.cross and globals.flag_cross_finish == 1 and stop == False:
                    globals.yuyin.play_audio(audio_file)
                    stop = True

                # 检测锥桶位置
                # 检测锥桶位置
                if globals.flag_cross_finish == 1 and globals.change_lane_done:
                    cone_position = globals.frame_processing.detect_cone(globals.frame)

                    # 更新滑动窗口列表，只保存最近的 `detection_threshold` 帧
                    globals.cone_position_history.append(cone_position)
                    if len(globals.cone_position_history) > globals.detection_threshold:
                        globals.cone_position_history.pop(0)  # 保持列表长度不超过 `detection_threshold`

                    # 计算有效检测到锥桶的帧数
                    valid_detections = sum(1 for pos in globals.cone_position_history if pos is not None)

                    # 如果有效检测次数达到阈值，确认锥桶位置
                    if valid_detections >= globals.detection_threshold:
                        globals.cone_position = cone_position  # 确认锥桶位置
                        print("锥桶位置已确认，准备避障")
                        globals.cone_position_history.clear()
                    else:
                        globals.cone_position = None  # 否则暂不认为检测有效

                globals.m_scontrol.motor_servo_control(globals.yellow_num_hsv, globals.cross)

                duration = (end_time - start_time) / globals.cv2.getTickFrequency() * 1000  # 转换为毫秒
                print(f"Times: {duration:.2f} ms")
                start_time = end_time

                # globals.cv2.imshow("frame", globals.frame)
                # globals.cv2.imshow("frame2", globals.bin_image)
                # globals.cv2.imshow("frame3", globals.bin_image2)

                key = globals.cv2.waitKey(1)
                if key == 27:  # ESC键
                    break
    finally:
        release_resources()


if __name__ == "__main__":
    main()



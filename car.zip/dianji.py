import pigpio as pio
import time
import os

# 启动pigpio守护进程
os.system("sudo pigpiod")
time.sleep(2)  # 等待守护进程启动

# GPIO初始化
motor_pin = 13  # 定义pwm输出引脚：电调口 13
pi = pio.pi()  # 实例化pigpio对象

# 检查是否成功连接到pigpio守护进程
if not pi.connected:
    print("无法连接到pigpio守护进程，请确保pigpio守护进程已启动。")
    exit()

pi.set_mode(motor_pin, pio.OUTPUT)  # 设置PWM引脚为输出状态

# PWM初始化
pi.set_PWM_frequency(motor_pin, 200)  # 设定13号引脚产生的pwm波形的频率为200Hz 
pi.set_PWM_range(motor_pin, 40000)  # 限制占空比的范围（一个pwm周期分成多少份），总范围25-40000。

# 电调响应
pi.set_PWM_dutycycle(motor_pin, 10000)  # 指定pwm波形脉宽
time.sleep(2)

def test_forward():
    for dy in range(8000, 10000, 100):
        pi.set_PWM_dutycycle(motor_pin, dy)
        print(f"Forward duty cycle: {dy}")
        time.sleep(3)

def test_backward():
    # 寻找后转
    for dy in range(5800, 6500, 50):
        pi.set_PWM_dutycycle(motor_pin, dy)
        print(f"Backward duty cycle: {dy}")
        time.sleep(2)

def dian(run_time):
    start_time = time.time()
    while time.time() - start_time < run_time:
        pi.set_PWM_dutycycle(motor_pin, 8800)  # 电机运行
        time.sleep(1)
    pi.set_PWM_dutycycle(motor_pin, 10000)  # 停止电机，设置为中性位置
    print("电机已停止")

try:
    # 调用前转和后转测试函数
    print("Starting forward test...")
    #test_forward()
    print("Forward test complete.")

    # 短暂休息，以便重新测试
    time.sleep(5)

    print("Starting backward test...")
    #test_backward()
    print("Backward test complete.")

    # 调用dian函数进行持续测试，运行10秒后停止
    dian(10)

except KeyboardInterrupt:
    print("用户中断，程序即将退出...")

finally:
    # 确保释放资源和关闭pigpio守护进程
    pi.set_PWM_dutycycle(motor_pin, 10000)  # 停止电机
    pi.stop()  # 关闭pigpio连接
    os.system("sudo killall pigpiod")  # 关闭pigpio守护进程
    print("pigpio守护进程已关闭。")

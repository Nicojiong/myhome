
import globals


# # 750  820  910
def servo_motor_pwm_init():
    """ 初始化伺服电机和电机的PWM配置 """
    # 初始化GPIO库
    globals.pi = globals.pigpio.pi()
    if not globals.pi.connected:
        print("GPIO failed")
        return
    else:
        print("GPIO ok")

    # 设置伺服电机的GPIO引脚为输出模式
    globals.pi.set_PWM_frequency(globals.SERVO_PIN, globals.SERVO_PWM_FREQUENCY)
    globals.pi.set_PWM_range(globals.SERVO_PIN, globals.SERVO_PWM_RANGE)
    globals.pi.set_PWM_dutycycle(globals.SERVO_PIN, globals.SERVO_PWM_DUTY_CYCLE_UNLOCK)

    # 设置电机的PWM频率、范围和初始占空比
    globals.pi.set_PWM_frequency(globals.MOTOR_PIN, globals.MOTOR_PWM_FREQUENCY)
    globals.pi.set_PWM_range(globals.MOTOR_PIN, globals.MOTOR_PWM_RANGE)
    globals.pi.set_PWM_dutycycle(globals.MOTOR_PIN, globals.MOTOR_PWM_DUTY_CYCLE_UNLOCK)


def servo_pd_after(target):
    size = len(globals.mid)  # 获取mid列表的大小

    # 计算pidx为中线点的x坐标平均值
    pidx = int((globals.mid[23][0] + globals.mid[20][0] + globals.mid[25][0]) / 3)

    # 计算误差error_first
    globals.error_first = target - pidx

    # 使用PD控制器计算伺服电机的PWM差值
    globals.servo_pwm_diff = globals.kp * globals.error_first + globals.kd * (globals.error_first - globals.last_error)

    # 更新last_error
    globals.last_error = globals.error_first

    # 计算最终的PWM值
    globals.servo_pwm = 820 + globals.servo_pwm_diff

    # 限制servo_pwm的范围
    if globals.servo_pwm > 870:
        globals.servo_pwm = 870
    elif globals.servo_pwm < 790:
        globals.servo_pwm = 790

    return globals.servo_pwm  # 返回计算后的PWM值


def servo_pd(target):
    size = len(globals.mid)  # 获取mid列表的大小
    if len(globals.mid) < 26:  # 确保 mid 有足够的点供计算
        print("mid 列表数据不足，无法计算伺服调节。")
        return None  # 返回None表示无法继续

    print(f"Mid[20]: {globals.mid[20]}, Mid[23]: {globals.mid[23]}, Mid[25]: {globals.mid[25]}")
    # 计算pidx为中线点的x坐标平均值
    pidx = int((globals.mid[23][0] + globals.mid[20][0] + globals.mid[25][0]) / 3)

    # 计算误差error_first
    globals.error_first = target - pidx

    # 使用PD控制器计算伺服电机的PWM差值
    globals.servo_pwm_diff = globals.kp * globals.error_first + globals.kd * (globals.error_first - globals.last_error)

    # 更新last_error
    globals.last_error = globals.error_first

    # 计算最终的PWM值
    globals.servo_pwm = 820 + globals.servo_pwm_diff

    # 限制servo_pwm的范围
    if globals.servo_pwm > 870:
        globals.servo_pwm = 870
    elif globals.servo_pwm < 790:
        globals.servo_pwm = 790

    print(
        f"Error: {globals.error_first}, Servo PWM diff: {globals.servo_pwm_diff}, Calculated PWM: {globals.servo_pwm}")

    return globals.servo_pwm  # 返回计算后的PWM值


def blue_servo(target):
    size = len(globals.mid)  # 获取mid列表的大小
    if len(globals.mid) < 26:  # 确保 mid 有足够的点供计算
        print("mid 列表数据不足，无法计算伺服调节。")
        return None  # 返回None表示无法继续

    print(f"Mid[20]: {globals.mid[20]}, Mid[23]: {globals.mid[23]}, Mid[25]: {globals.mid[25]}")
    # 计算pidx为中线点的x坐标平均值
    pidx = int((globals.mid[23][0] + globals.mid[20][0] + globals.mid[25][0]) / 3)

    # 计算误差error_first
    globals.error_first = target - pidx

    # 使用PD控制器计算伺服电机的PWM差值
    globals.servo_pwm_diff = globals.kp * globals.error_first + globals.kd * (globals.error_first - globals.last_error)

    # 更新last_error
    globals.last_error = globals.error_first

    # 计算最终的PWM值
    globals.servo_pwm = 820 + globals.servo_pwm_diff

    # 限制servo_pwm的范围
    if globals.servo_pwm > 900:
        globals.servo_pwm = 900
    elif globals.servo_pwm < 770:
        globals.servo_pwm = 770

    print(
        f"Error: {globals.error_first}, Servo PWM diff: {globals.servo_pwm_diff}, Calculated PWM: {globals.servo_pwm}")

    return globals.servo_pwm  # 返回计算后的PWM值


def turn_servo(target):
    size = len(globals.mid)  # 获取mid列表的大小
    if len(globals.mid) < 26:  # 确保 mid 有足够的点供计算
        print("mid 列表数据不足，无法计算伺服调节。")
        return None  # 返回None表示无法继续

    print(f"Mid[20]: {globals.mid[20]}, Mid[23]: {globals.mid[23]}, Mid[25]: {globals.mid[25]}")
    # 计算pidx为中线点的x坐标平均值
    pidx = int((globals.mid[23][0] + globals.mid[20][0] + globals.mid[25][0]) / 3)

    # 计算误差error_first
    globals.error_first = target - pidx

    # 使用PD控制器计算伺服电机的PWM差值
    globals.servo_pwm_diff = globals.kp * globals.error_first + globals.kd * (globals.error_first - globals.last_error)

    # 更新last_error
    globals.last_error = globals.error_first

    # 计算最终的PWM值
    globals.servo_pwm = 820 + globals.servo_pwm_diff

    # 限制servo_pwm的范围
    if globals.servo_pwm > 970:
        globals.servo_pwm = 970
    elif globals.servo_pwm < 770:
        globals.servo_pwm = 770

    print(
        f"Error: {globals.error_first}, Servo PWM diff: {globals.servo_pwm_diff}, Calculated PWM: {globals.servo_pwm}")

    return globals.servo_pwm  # 返回计算后的PWM值


def motor_servo_control(flag_yellow_cond, cross):
    # 锥桶方案
    if flag_yellow_cond != 0 and globals.flag_yellow_finish == 0 and globals.flag_cross_finish == 1:
#    if  globals.flag_yellow_finish == 0 and globals.flag_cross_finish == 1 and globals.count_change >2:
        #    if globals.flag_yellow_finish == 0 and globals.flag_cross_finish == 1 and globals.count_change>2:
        #        globals.flag_yellow_finish = 1
        print("come")
        #        globals.pi.set_PWM_dutycycle(12, 820)
        #        globals.pi.set_PWM_dutycycle(13, 9500)
        #        globals.time.sleep(0.5)
        #        globals.pi.set_PWM_dutycycle(12, 820)
        #        globals.pi.set_PWM_dutycycle(13, 10000)
        #        globals.time.sleep(2)

        # globals.pi.set_PWM_dutycycle(12, 825)  # 设置伺服电机PWM
        # globals.pi.set_PWM_dutycycle(13, 10000)  # 设置电机PWM
        # globals.time.sleep(0.25)  # 暂停250毫秒
        # exit(0)  # 退出程序或当前进程
        # 根据 recognized_id 进行停止逻辑
        if globals.recognized_id == 0:  # 左转停下
            # 设置电机向前运动
            globals.pi.set_PWM_dutycycle(13, 9530)
            # 调整伺服电机角度以左转
            globals.pi.set_PWM_dutycycle(12, 850)
            globals.time.sleep(1.3)  # 左转1秒

            # 调整伺服电机角度以右转
            globals.pi.set_PWM_dutycycle(12, 780)  # 设置为右转角度
            globals.time.sleep(0.8)  # 右转1秒

            # 回正舵机
            globals.pi.set_PWM_dutycycle(12, 820)  # 回正舵机
            globals.pi.set_PWM_dutycycle(13, 9530)
            globals.time.sleep(0.4)
            globals.pi.set_PWM_dutycycle(13, 0)  # 停止电机
            print("左转停下、右转并回正舵机")
            exit(0)  # 退出程序或当前进程

        elif globals.recognized_id == 1:  # 右转停下
            # 设置电机向前运动
            globals.pi.set_PWM_dutycycle(13, 9490)
            # 调整伺服电机角度以左转
            globals.pi.set_PWM_dutycycle(12, 780)
            globals.time.sleep(1.4)  # 左转1秒

            # 调整伺服电机角度以右转
            globals.pi.set_PWM_dutycycle(12, 850)  # 设置为右转角度
            globals.time.sleep(0.8)  # 右转1秒

            # 回正舵机
            globals.pi.set_PWM_dutycycle(12, 820)  # 回正舵机
            globals.pi.set_PWM_dutycycle(13, 9500)
            globals.time.sleep(0.5)
            globals.pi.set_PWM_dutycycle(13, 0)  # 停止电机
            print("右转停下并回正舵机")
            exit(0)  # 退出程序或当前进程

    #        exit(0)  # 退出程序或当前进程

    elif globals.cross == 1 and globals.flag_cross_finish == 0 and globals.yuyintag == 0:
        globals.flag_cross_finish = 1

        globals.pi.set_PWM_dutycycle(12, 820)
        globals.pi.set_PWM_dutycycle(13, 9400)
        globals.time.sleep(0.5)  # 暂停550毫秒
        globals.pi.set_PWM_dutycycle(13, 10000)
        globals.time.sleep(2)  # 暂停550毫秒
        globals.yuyintag = 1
        # 在原有的控制逻辑中
    elif globals.flag_cross_finish == 1 and not globals.change_lane_done:
        globals.turn_crossroad=0
        if globals.turn_crossroad == 0:
            # 向左转的控制逻辑
            left_turn_pwm = 858  # 设置适合的 PWM 值来实现向左转
            globals.pi.set_PWM_dutycycle(12, left_turn_pwm)  # 设置舵机 PWM
            globals.pi.set_PWM_dutycycle(13, 9430)  # 设置电机 PWM
            print("Turning left...")
            globals.time.sleep(2.9)  # 向左转1秒11.9

            # 回正的控制逻辑
            globals.pi.set_PWM_dutycycle(12, 775)  # 回正舵机
            globals.pi.set_PWM_dutycycle(13, 9420)  # 继续电机 PWM
            print("Returning to straight...")
            globals.time.sleep(1.3)  # 向左转1秒
#            globals.pi.set_PWM_dutycycle(12, 820)  # 回正舵机
#            globals.pi.set_PWM_dutycycle(13, 9420)  # 继续电机 PWM

            # 设置换道完成标志
            globals.change_lane_done = True  # 记录换道完成
        elif globals.turn_crossroad == 1:
            # 右转的控制逻辑
            right_turn_pwm = 700  # 设置适合的 PWM 值来实现右转
            globals.pi.set_PWM_dutycycle(12, right_turn_pwm)  # 设置舵机 PWM
            globals.pi.set_PWM_dutycycle(13, 9420)  # 设置电机 PWM
            print("Turning right...")
            globals.time.sleep(3.1)  # 向右转1秒

            # 回正的控制逻辑
            globals.pi.set_PWM_dutycycle(12, 800)  # 回正舵机
            globals.pi.set_PWM_dutycycle(13, 9420)  # 继续电机 PWM
            print("Returning to straight...")
            globals.time.sleep(1.8)  # 向左转1秒
            globals.pi.set_PWM_dutycycle(12, 820)  # 回正舵机
            globals.pi.set_PWM_dutycycle(13, 9420)  # 继续电机 PWM
            # 设置换道完成标志
            globals.change_lane_done = True  # 记录换道完成
        # if globals.turn_crossroad == 0:
        #     globals.servo_pwm_now = turn_servo(160)
        #     globals.pi.set_PWM_dutycycle(12, globals.servo_pwm_now)
        #     globals.pi.set_PWM_dutycycle(13, 9500)
        # elif globals.turn_crossroad == 1:
        #     globals.pi.set_PWM_dutycycle(12, 680)
        #     globals.pi.set_PWM_dutycycle(13, 9400)
        #     globals.time.sleep(2.4)  # 向左转1秒
        #     globals.servo_pwm_now = turn_servo(160)
        #     globals.pi.set_PWM_dutycycle(12, globals.servo_pwm_now)
        #     globals.pi.set_PWM_dutycycle(13, 9400)
    #     elif globals.cone_position is not None and globals.flag_cross_finish == 1 and globals.count_change < 3:
    #         x, y, w, h = globals.cone_position
    #         print(f"{x},{y},{w},{h}")
    #         center_x = x + w / 2
    #         # 设置舵机角度根据锥桶位置决定转向
    #         if center_x < 160 :  # 320 宽度情况下，160 为中心，锥桶在左
    #             globals.pi.set_PWM_dutycycle(12, 740)
    #             globals.pi.set_PWM_dutycycle(13, 11000)  # 11000
    #             globals.time.sleep(1)
    #             globals.pi.set_PWM_dutycycle(12, 920)
    #             globals.pi.set_PWM_dutycycle(13, 11100)  # 11100
    #             globals.time.sleep(2)
    # #            globals.pi.set_PWM_dutycycle(12, 825)
    # #            globals.pi.set_PWM_dutycycle(13, 11100)  # 11100
    # #            globals.time.sleep(0.8)
    #             globals.cone_position=None
    #             globals.count_change += 1
    #             print(f"{globals.cone_position}")
    #             print("锥桶在左侧，右转避障")
    #         else :  # 锥桶在右
    #             globals.pi.set_PWM_dutycycle(12, 900)
    #             globals.pi.set_PWM_dutycycle(13, 11000)  # 11500
    #             globals.time.sleep(1)
    #             globals.pi.set_PWM_dutycycle(12, 820)
    #             globals.pi.set_PWM_dutycycle(13, 11100)  # 11500
    #             globals.time.sleep(1.8)
    # #            globals.pi.set_PWM_dutycycle(12, 825)
    # #            globals.pi.set_PWM_dutycycle(13, 11100)  # 11500
    # #            globals.time.sleep(0.8)
    #             globals.cone_position=None
    #             globals.count_change += 1
    #             print("锥桶在右侧，左转避障")
    #             # 避障完成后更新计数和标志位
    #         print(f"已避障 {globals.count_change} 次")
    # 在避障逻辑中使用 turn_direction 判断绕行方向
    elif globals.cone_position is not None and globals.flag_cross_finish == 1 and globals.change_lane_done and globals.count_change < 3:
        x, y, w, h = globals.cone_position
        center_x = x + w / 2

        if globals.turn_direction == 'right':
            # 执行右绕避障逻辑
            globals.pi.set_PWM_dutycycle(12, 785)
            globals.pi.set_PWM_dutycycle(13, 9420)  # 9380
            globals.time.sleep(1.1)
            globals.pi.set_PWM_dutycycle(12, 860)
            globals.pi.set_PWM_dutycycle(13, 9420)
            globals.time.sleep(1.0)
            print("右绕避障完成")
            globals.turn_direction = 'left'  # 更新绕行方向

        elif globals.turn_direction == 'left':
            # 执行左绕避障逻辑
            globals.pi.set_PWM_dutycycle(12, 860)
            globals.pi.set_PWM_dutycycle(13, 9420)
            globals.time.sleep(1.0)
            globals.pi.set_PWM_dutycycle(12, 770)
            globals.pi.set_PWM_dutycycle(13, 9420)
            globals.time.sleep(1.2)
            print("左绕避障完成")
            globals.turn_direction = 'right'  # 更新绕行方向

        # 清除当前位置，更新计数
        globals.cone_position = None
        globals.count_change += 1
        print(f"已避障 {globals.count_change} 次")
    else:
        if globals.count_change < 1 or globals.count_change > 2:
            print(1)
            if globals.count_change > 2 and globals.flag_cross_finish == 1:
                globals.servo_pwm_now = servo_pd(160)
                print("pwm", globals.servo_pwm_now)
                # globals.pi.set_PWM_dutycycle(13, 12000)
                globals.pi.set_PWM_dutycycle(12, globals.servo_pwm_now)
                globals.number2 += 1
                print(f"number2={globals.number1}")
                if globals.number2 > 150:  # 800
                    globals.pi.set_PWM_dutycycle(13, 9450)  # 9390
                else:
                    globals.pi.set_PWM_dutycycle(13, 9390)  # 9200 9400
            elif globals.count_change < 1 and globals.flag_cross_finish == 0:
                globals.servo_pwm_now = servo_pd(160)
                print("pwm", globals.servo_pwm_now)
                print("这里是正常循迹")
                # globals.pi.set_PWM_dutycycle(13, 12000)  # 11500 
                globals.pi.set_PWM_dutycycle(12, globals.servo_pwm_now)
                globals.number1 += 1
                print(f"number1={globals.number1}")
                if globals.number1 > 1130:  # 1200
                    globals.pi.set_PWM_dutycycle(13, 9320)
                else:
                    globals.pi.set_PWM_dutycycle(13, 9150)  # 9150
                    print("你好")
            else:
                # 检查是否换道完成
                if globals.change_lane_done:
                    print("after")
                    globals.servo_pwm_now = servo_pd_after(160)
                    print("pwm", globals.servo_pwm_now)
                    globals.pi.set_PWM_dutycycle(13, 9400)
                    globals.pi.set_PWM_dutycycle(12, globals.servo_pwm_now)

        else:
            print(2)
            globals.servo_pwm_now = blue_servo(160)
            print("pwm", globals.servo_pwm_now)
            globals.pi.set_PWM_dutycycle(13, 9420)
            globals.pi.set_PWM_dutycycle(12, globals.servo_pwm_now)

